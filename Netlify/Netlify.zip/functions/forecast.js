// HELIOSICA Netlify Function - GSSI Forecast
// Returns GSSI forecast data

const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const hours = parseInt(event.queryStringParameters?.hours) || 48;
    
    // Get recent GSSI data for trend
    const { data: recent, error } = await supabase
      .from('gssi_data')
      .select('timestamp, gssi_value, gssi_category')
      .order('timestamp', { ascending: false })
      .limit(24); // Last 24 points (3 days if 3-hour intervals)
    
    if (error) throw error;

    // Generate simple forecast based on trend
    const forecast = [];
    const lastTime = recent[0]?.timestamp ? new Date(recent[0].timestamp) : new Date();
    const lastValue = recent[0]?.gssi_value || 0.12;
    
    for (let i = 1; i <= hours / 3; i++) {
      const forecastTime = new Date(lastTime);
      forecastTime.setHours(forecastTime.getHours() + i * 3);
      
      // Simple persistence forecast
      let forecastValue = lastValue;
      let forecastCategory = 'G0';
      
      if (forecastValue < 0.2) forecastCategory = 'G0';
      else if (forecastValue < 0.3) forecastCategory = 'G1';
      else if (forecastValue < 0.45) forecastCategory = 'G2';
      else if (forecastValue < 0.6) forecastCategory = 'G3';
      else if (forecastValue < 0.75) forecastCategory = 'G4';
      else forecastCategory = 'G5';
      
      forecast.push({
        timestamp: forecastTime.toISOString(),
        gssi_value: parseFloat(forecastValue.toFixed(3)),
        gssi_category: forecastCategory
      });
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        historical: recent,
        forecast: forecast
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
