// HELIOSICA Netlify Function - Shared Utilities
// Helper functions for database connections

const { createClient } = require('@supabase/supabase-js');

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing Supabase credentials in utils');
}

const supabase = createClient(supabaseUrl || '', supabaseKey || '');

// Get station by code
async function getStationByCode(stationCode) {
  const { data, error } = await supabase
    .from('stations')
    .select('*')
    .eq('station_code', stationCode)
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

// Get GSSI category from value
function getGssiCategory(gssi) {
  if (gssi < 0.2) return 'G0';
  if (gssi < 0.3) return 'G1';
  if (gssi < 0.45) return 'G2';
  if (gssi < 0.6) return 'G3';
  if (gssi < 0.75) return 'G4';
  return 'G5';
}

// Format response
function formatResponse(statusCode, data, error = null) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  const body = error 
    ? { success: false, error: error.message }
    : { success: true, ...data };

  return {
    statusCode,
    headers,
    body: JSON.stringify(body)
  };
}

// Get timestamp
function getTimestamp() {
  return new Date().toISOString();
}

module.exports = {
  supabase,
  getStationByCode,
  getGssiCategory,
  formatResponse,
  getTimestamp
};
