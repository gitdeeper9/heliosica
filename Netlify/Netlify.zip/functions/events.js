// HELIOSICA Netlify Function - Storm Events API
// Returns storm events for map and charts

const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing Supabase credentials');
}

const supabase = createClient(supabaseUrl || '', supabaseKey || '');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  try {
    const year = event.queryStringParameters?.year;
    const minKp = event.queryStringParameters?.min_kp;
    
    let query = supabase
      .from('storm_events')
      .select('*')
      .order('event_date', { ascending: false });
    
    if (year) {
      query = query.gte('event_date', `${year}-01-01`).lte('event_date', `${year}-12-31`);
    }
    
    if (minKp) {
      query = query.gte('kp_max', parseFloat(minKp));
    }
    
    const { data: events, error } = await query;
    
    if (error) throw error;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        count: events?.length || 0,
        events: events || []
      })
    };
  } catch (error) {
    console.error('Error in events function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
