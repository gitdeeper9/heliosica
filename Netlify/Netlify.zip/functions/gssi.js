// HELIOSICA Netlify Function - GSSI Data API
// Returns GSSI time series for charts

const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing Supabase credentials');
}

const supabase = createClient(supabaseUrl || '', supabaseKey || '');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  try {
    const limit = parseInt(event.queryStringParameters?.limit) || 48;
    
    const { data, error } = await supabase
      .from('gssi_data')
      .select('timestamp, gssi_value, gssi_category')
      .order('timestamp', { ascending: false })
      .limit(limit);
    
    if (error) throw error;

    // Reverse to show chronological order
    const sortedData = (data || []).reverse();

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        count: sortedData.length,
        data: sortedData
      })
    };
  } catch (error) {
    console.error('Error in gssi function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
