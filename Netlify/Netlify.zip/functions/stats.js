// HELIOSICA Netlify Function - Statistics
// Returns database statistics

const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing Supabase credentials');
}

const supabase = createClient(supabaseUrl || '', supabaseKey || '');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  try {
    // Get counts from all tables
    const [solarCount, gssiCount, kpCount, dstCount, stormCount, stationCount] = await Promise.all([
      supabase.from('solar_wind').select('*', { count: 'exact', head: true }),
      supabase.from('gssi_data').select('*', { count: 'exact', head: true }),
      supabase.from('kp_data').select('*', { count: 'exact', head: true }),
      supabase.from('dst_data').select('*', { count: 'exact', head: true }),
      supabase.from('storm_events').select('*', { count: 'exact', head: true }),
      supabase.from('neutron_stations').select('*', { count: 'exact', head: true })
    ]);

    // Get latest GSSI
    const { data: latestGssi } = await supabase
      .from('gssi_data')
      .select('gssi_value, gssi_category, timestamp')
      .order('timestamp', { ascending: false })
      .limit(1)
      .maybeSingle();

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        stats: {
          solar_wind: solarCount.count || 0,
          gssi_data: gssiCount.count || 0,
          kp_data: kpCount.count || 0,
          dst_data: dstCount.count || 0,
          storm_events: stormCount.count || 0,
          stations: stationCount.count || 0
        },
        current: latestGssi || null
      })
    };
  } catch (error) {
    console.error('Error in stats function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
