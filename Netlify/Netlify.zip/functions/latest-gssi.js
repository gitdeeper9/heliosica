// HELIOSICA Netlify Function - Latest GSSI
// Returns current GSSI value from database

const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    // Get latest GSSI data
    const { data: gssi, error } = await supabase
      .from('gssi_data')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(1)
      .single();
    
    if (error) throw error;

    // Get current solar wind
    const { data: solar, error: solarError } = await supabase
      .from('solar_wind')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(1)
      .single();
    
    if (solarError && solarError.code !== 'PGRST116') throw solarError;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        gssi: gssi.gssi_value,
        category: gssi.gssi_category,
        timestamp: gssi.timestamp,
        current: {
          bz: solar?.bz || null,
          speed: solar?.speed || null,
          density: solar?.density || null
        }
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
