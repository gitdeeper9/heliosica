// HELIOSICA Netlify Function - Current Conditions
// Returns current space weather conditions

const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing Supabase credentials');
}

const supabase = createClient(supabaseUrl || '', supabaseKey || '');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  try {
    // Get latest GSSI
    const { data: gssi, error: gssiError } = await supabase
      .from('gssi_data')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(1)
      .maybeSingle();
    
    if (gssiError) throw gssiError;

    // Get latest solar wind
    const { data: solar, error: solarError } = await supabase
      .from('solar_wind')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(1)
      .maybeSingle();
    
    if (solarError) throw solarError;

    // Get latest Kp
    const { data: kp, error: kpError } = await supabase
      .from('kp_data')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(1)
      .maybeSingle();
    
    if (kpError) throw kpError;

    // Get latest Dst
    const { data: dst, error: dstError } = await supabase
      .from('dst_data')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(1)
      .maybeSingle();
    
    if (dstError) throw dstError;

    // Get latest magnetopause
    const { data: mp, error: mpError } = await supabase
      .from('magnetopause_data')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(1)
      .maybeSingle();
    
    if (mpError) throw mpError;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        gssi: gssi || null,
        solar_wind: solar || null,
        kp: kp || null,
        dst: dst || null,
        magnetopause: mp || null,
        timestamp: new Date().toISOString()
      })
    };
  } catch (error) {
    console.error('Error in current function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
