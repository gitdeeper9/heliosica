// HELIOSICA Netlify Function - Stations API
// Returns all stations from the three station tables

const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing Supabase credentials');
}

const supabase = createClient(supabaseUrl || '', supabaseKey || '');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  try {
    // Get stations from the three tables (ignore 'stations' table as it's empty)
    const [neutron, magnetometer, satellites] = await Promise.all([
      supabase.from('neutron_stations').select('*'),
      supabase.from('magnetometer_stations').select('*'),
      supabase.from('satellites').select('*')
    ]);

    if (neutron.error) {
      console.error('Error fetching neutron_stations:', neutron.error);
      throw neutron.error;
    }
    if (magnetometer.error) {
      console.error('Error fetching magnetometer_stations:', magnetometer.error);
      throw magnetometer.error;
    }
    if (satellites.error) {
      console.error('Error fetching satellites:', satellites.error);
      throw satellites.error;
    }

    // Format neutron stations
    const neutronStations = (neutron.data || []).map(s => ({
      station_code: s.station_code,
      station_name: s.station_name,
      latitude: s.latitude,
      longitude: s.longitude,
      altitude: s.altitude,
      country: s.country,
      type: 'neutron',
      cutoff_rigidity: s.cutoff_rigidity
    }));

    // Format magnetometer stations
    const magnetometerStations = (magnetometer.data || []).map(s => ({
      station_code: s.station_code,
      station_name: s.station_name,
      latitude: s.latitude,
      longitude: s.longitude,
      country: s.country,
      type: 'magnetometer',
      network: s.network
    }));

    // Format satellites
    const satelliteStations = (satellites.data || []).map(s => ({
      station_code: s.satellite_code,
      station_name: s.satellite_name,
      latitude: 0,
      longitude: 0,
      type: 'satellite',
      orbit_type: s.orbit_type,
      distance_from_earth: s.distance_from_earth
    }));

    const allStations = [
      ...neutronStations,
      ...magnetometerStations,
      ...satelliteStations
    ];

    console.log(`Found ${allStations.length} stations: ${neutronStations.length} neutron, ${magnetometerStations.length} magnetometer, ${satelliteStations.length} satellites`);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        count: allStations.length,
        stations: allStations
      })
    };
  } catch (error) {
    console.error('Error in stations function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
