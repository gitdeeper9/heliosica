// HELIOSICA Netlify Function - Alerts API
// Returns real alerts from database

const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing Supabase credentials');
}

const supabase = createClient(supabaseUrl || '', supabaseKey || '');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  try {
    const activeOnly = event.queryStringParameters?.active !== 'false';
    
    let query = supabase
      .from('alerts')
      .select('*')
      .order('alert_time', { ascending: false });
    
    if (activeOnly) {
      query = query.gt('expires_at', new Date().toISOString());
    }
    
    const { data: alerts, error } = await query;
    
    if (error) throw error;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        count: alerts?.length || 0,
        alerts: alerts || []
      })
    };
  } catch (error) {
    console.error('Error in alerts function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
