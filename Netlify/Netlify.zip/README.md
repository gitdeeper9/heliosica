
# ☀️ HELIOSICA Netlify Dashboard

**Heliospheric Event and L1 Integrated Observatory for Solar Intelligence and Coronal Activity**

[![Netlify Status](https://api.netlify.com/api/v1/badges/heliosica/deploy-status)](https://heliosica.netlify.app)
[![DOI](https://img.shields.io/badge/DOI-10.5281%2Fzenodo.19082026-orange)](https://doi.org/10.5281/zenodo.19082026)
[![Python](https://img.shields.io/badge/Python-3.9%2B-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green)](LICENSE)

---

## 🚀 Live Dashboard
- **Dashboard:** [https://heliosica.netlify.app](https://heliosica.netlify.app)
- **API:** [https://heliosica.netlify.app/api](https://heliosica.netlify.app/api)
- **GSSI Monitor:** [https://heliosica.netlify.app/gssi](https://heliosica.netlify.app/gssi)
- **SPIN Parameters:** [https://heliosica.netlify.app/spin](https://heliosica.netlify.app/spin)
- **Forecast:** [https://heliosica.netlify.app/forecast](https://heliosica.netlify.app/forecast)
- **Magnetopause:** [https://heliosica.netlify.app/magnetopause](https://heliosica.netlify.app/magnetopause)
- **Documentation:** [https://heliosica.netlify.app/docs](https://heliosica.netlify.app/docs)

## 📊 Current Status (2026)

| Metric | Value |
|--------|-------|
| **Validation Events** | 312 |
| **Current GSSI** | 0.12 |
| **Status** | 🟢 G0 (Quiet) |
| Average E<sub>y</sub> | 2.3 mV/m |
| Average Kp | 1.8 |
| Major Storms (G4+) | 47 |
| Lead Time | 24-48 hours |

## 📡 API Endpoints

| Endpoint | Description | Parameters |
|----------|-------------|------------|
| `/api/current` | Current conditions | - |
| `/api/gssi` | GSSI calculation | `ey`, `bz`, `p_ram`, `vsw` |
| `/api/forecast` | 48-hour forecast | - |
| `/api/events` | Storm events list | `year`, `min_kp` |
| `/api/event/{id}` | Single storm event | `id` |
| `/api/stations` | All stations | `type` |
| `/api/station/{code}` | Station data | `code` |
| `/api/dbm` | CME transit prediction | `v0`, `omega`, `np` |
| `/api/magnetopause` | R<sub>MP</sub> calculation | `p_ram` |
| `/api/forbush` | Forbush events | `station`, `days` |
| `/api/alerts` | Active alerts | - |

### Example API Call
```bash
# Get current conditions
curl https://heliosica.netlify.app/api/current

# Calculate GSSI
curl https://heliosica.netlify.app/api/gssi?ey=6.5&bz=-14&p_ram=12.3&vsw=620

# Get Halloween 2003 event data
curl https://heliosica.netlify.app/api/event/2003-10-29

# CME transit prediction
curl https://heliosica.netlify.app/api/dbm?v0=2459&omega=360&np=15
```

📈 Key Metrics

Metric Value
GSSI Accuracy 88.4%
CME Arrival RMSE 4.2 hrs
Kp Prediction r² 0.91
Events in Catalogue 312
Major Storms (G4+) 47
Magnetopause RMSE 0.71 R<sub>E</sub>
E<sub>y</sub>-Kp Correlation r = 0.871

🔧 Local Development

```bash
# Clone repository
git clone https://github.com/gitdeeper9/heliosica.git
cd heliosica/Netlify

# Install Netlify CLI
npm install -g netlify-cli

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your Supabase credentials

# Start local server
netlify dev
```

🏗️ Project Structure

```
Netlify/
├── public/                 # Static files
│   ├── index.html         # Main landing page
│   ├── dashboard.html      # Live dashboard
│   ├── gssi.html          # GSSI monitor
│   ├── spin-parameters.html # SPIN parameters
│   ├── forecast.html      # Forecast page
│   ├── magnetopause.html  # Magnetopause tracker
│   ├── storm-events.html  # Storm events
│   ├── stations-map.html  # Stations map
│   └── reports.html        # Reports archive
├── functions/              # Netlify Functions
│   ├── current.js         # Current conditions
│   ├── gssi.js            # GSSI calculation
│   ├── forecast.js        # 48-hour forecast
│   ├── events.js          # Storm events list
│   ├── event.js           # Single storm event
│   ├── stations.js        # All stations
│   ├── station.js         # Single station
│   ├── dbm.js             # DBM prediction
│   ├── magnetopause.js    # R<sub>MP</sub> calculation
│   ├── forbush.js         # Forbush events
│   └── alerts.js          # Active alerts
├── package.json           # Dependencies
├── netlify.toml           # Netlify configuration
└── .env.example           # Environment variables template
```

🗄️ Database Schema (Supabase)

```sql
-- Stations table
CREATE TABLE stations (
  id SERIAL PRIMARY KEY,
  station_code VARCHAR(20) UNIQUE NOT NULL,
  station_name VARCHAR(100) NOT NULL,
  station_type VARCHAR(50) NOT NULL,
  latitude DECIMAL(10,6) NOT NULL,
  longitude DECIMAL(10,6) NOT NULL,
  altitude DECIMAL(8,2),
  country VARCHAR(100),
  is_active BOOLEAN DEFAULT true
);

-- Solar wind data
CREATE TABLE solar_wind (
  id SERIAL PRIMARY KEY,
  timestamp TIMESTAMPTZ NOT NULL,
  station_code VARCHAR(20),
  bx DECIMAL(8,2),
  by DECIMAL(8,2),
  bz DECIMAL(8,2),
  bt DECIMAL(8,2),
  density DECIMAL(8,2),
  speed DECIMAL(8,2),
  temperature DECIMAL(10,2),
  pressure DECIMAL(10,4)
);

-- GSSI data
CREATE TABLE gssi_data (
  id SERIAL PRIMARY KEY,
  timestamp TIMESTAMPTZ NOT NULL,
  gssi_value DECIMAL(6,4),
  gssi_category VARCHAR(2),
  ey DECIMAL(8,2),
  bz DECIMAL(8,2),
  p_ram DECIMAL(10,4),
  v0 DECIMAL(8,2),
  gamma DECIMAL(12,10),
  omega DECIMAL(6,2),
  tp DECIMAL(10,2),
  fd DECIMAL(6,2),
  kp DECIMAL(4,2)
);

-- CME events
CREATE TABLE cme_events (
  id SERIAL PRIMARY KEY,
  cme_id VARCHAR(50) UNIQUE,
  observation_date TIMESTAMPTZ NOT NULL,
  velocity DECIMAL(8,2),
  angular_width DECIMAL(6,2),
  is_halo BOOLEAN,
  source_location VARCHAR(50)
);

-- Storm events
CREATE TABLE storm_events (
  id SERIAL PRIMARY KEY,
  event_date DATE NOT NULL,
  event_name VARCHAR(100),
  kp_max DECIMAL(4,2),
  dst_min INTEGER,
  gssi_max DECIMAL(6,4),
  gssi_category VARCHAR(2),
  latitude DECIMAL(10,6),
  longitude DECIMAL(10,6),
  description TEXT
);

-- Forbush events
CREATE TABLE forbush_events (
  id SERIAL PRIMARY KEY,
  event_id VARCHAR(50) UNIQUE,
  onset_time TIMESTAMPTZ NOT NULL,
  station_code VARCHAR(20),
  fd_percent DECIMAL(6,2),
  b_cloud DECIMAL(8,2),
  magnitude VARCHAR(20),
  cloud_confirmed BOOLEAN
);

-- Alerts
CREATE TABLE alerts (
  id SERIAL PRIMARY KEY,
  alert_time TIMESTAMPTZ NOT NULL,
  alert_type VARCHAR(50),
  alert_level VARCHAR(20),
  gssi_value DECIMAL(6,4),
  r_mp_value DECIMAL(8,4),
  alert_message TEXT,
  expires_at TIMESTAMPTZ
);
```

📖 Citation

If you use HELIOSICA in your research, please cite:

```bibtex
@software{baladi2026heliosica,
  author = {Baladi, Samir},
  title = {HELIOSICA: Nine Parameters to Decode the Solar Wind and Shield Our Digital World},
  year = {2026},
  version = {1.0.0},
  doi = {10.5281/zenodo.19082026},
  url = {https://github.com/gitdeeper9/heliosica}
}
```

📬 Contact

· Author: Samir Baladi
· Email: gitdeeper@gmail.com
· ORCID: 0009-0003-8903-0029
· GitHub: github.com/gitdeeper9/heliosica
· DOI: 10.5281/zenodo.19082026

---

☀️ HELIOSICA — Nine Parameters to Decode the Solar Wind and Shield Our Digital World.
